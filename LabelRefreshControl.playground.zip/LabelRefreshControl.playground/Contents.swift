import UIKit
import PlaygroundSupport
import SwiftUI

var str = "Hello, playground"

/// Usage: `labelRefreshControl.label.text = "myposter"`.
final class LabelRefreshControl: UIRefreshControl {
    // MARK: Properties

    private(set) lazy var label: UILabel = {
        // MARK: Container
        let contentView = UIView(frame: self.bounds)

        // MARK: Label
        let label = UILabel(frame: CGRect(
            origin: CGPoint(x: 0, y: 0),
            size: CGSize(width: contentView.bounds.size.width, height: 28)
        ))
        self.tintColor = .clear
        contentView.addSubview(label)

        // MARK: Activity indicator
        let activityIndicator = UIActivityIndicatorView(frame: CGRect(
            origin: CGPoint(x: label.bounds.width / 2 - 8, y: label.bounds.maxY + 2),
            size: CGSize(width: 8, height: 8)
        ))
        activityIndicator.color = .lightGray
        activityIndicator.startAnimating()
        contentView.addSubview(activityIndicator)

        self.addSubview(contentView)
        return label
    }()
}

let tableView = UITableView(frame: CGRect(origin: .zero, size: CGSize(width: 400, height: 200)))
tableView.refreshControl = LabelRefreshControl(frame: tableView.bounds)
tableView.backgroundColor = .systemBackground
let refreshControl = tableView.refreshControl as? LabelRefreshControl
refreshControl?.label.text = "Letzter Bild Upload am 26.05.2020"
refreshControl?.label.textAlignment = .center
refreshControl?.label.font = .systemFont(ofSize: 12)
refreshControl?.label.textColor = .brown
refreshControl?.backgroundColor = .white

//func endRefreshing() {
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + .seconds(5)) {
//        refreshControl?.endRefreshing()
//        endRefreshing()
//    }
//}
//endRefreshing()

private let deviceNames: [String] = [
    "iPhone 8",
    "iPhone 11 Pro",
    "iPad Pro (11-inch) (2nd generation)"
]

struct LabelRefreshControlViewRepresentable: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        let tableView = UITableView(frame: CGRect(origin: .zero, size: CGSize(width: 400, height: 200)))
        tableView.refreshControl = LabelRefreshControl(frame: tableView.bounds)
        tableView.backgroundColor = .systemBackground
        let refreshControl = tableView.refreshControl as? LabelRefreshControl
        refreshControl?.label.text = "Letzter Bild Upload am 26.05.2020"
        refreshControl?.label.textAlignment = .center
        refreshControl?.label.font = .systemFont(ofSize: 12)
        refreshControl?.label.textColor = .brown
        refreshControl?.backgroundColor = .white
        return tableView
    }

    func updateUIView(_ view: UIView, context: Context) {}
}

struct LabelRefreshControl_Previews: PreviewProvider {
    static var previews: some View {
        ForEach(deviceNames, id: \.self) { deviceName in
            LabelRefreshControlViewRepresentable()
                .previewDevice(PreviewDevice(rawValue: deviceName))
                .previewDisplayName(deviceName)
        }
    }
}

// https://www.hackingwithswift.com/articles/203/how-to-use-swiftui-in-swift-playgrounds
PlaygroundPage.current.setLiveView(LabelRefreshControl_Previews.previews)
PlaygroundPage.current.needsIndefiniteExecution = true
