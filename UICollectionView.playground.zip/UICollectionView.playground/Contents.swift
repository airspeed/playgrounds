import UIKit
import PlaygroundSupport

var str = "Hello, playground"
PlaygroundPage.current.needsIndefiniteExecution = true

let xs = (1...100).map { $0 }
let colors: [UIColor] = [.systemRed, .systemBlue, .systemPink, .systemTeal, .systemGray, .systemFill, .systemGreen, .systemRed, .systemOrange, .systemYellow, .systemPurple, .systemIndigo, .systemBackground, .systemGroupedBackground]

let rootView = UIView(frame: CGRect(x: 0, y: 0, width: 600, height: 1000))
rootView.backgroundColor = .gray

final class DataSource: NSObject, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        xs.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        let model = xs[indexPath.item]
        cell.tag = model
        cell.contentView.backgroundColor = colors.randomElement()
        cell.contentView.layer.borderColor = UIColor.darkText.cgColor
        cell.contentView.layer.cornerRadius = 25
        cell.contentView.layer.borderWidth = 0
        return cell
    }
}

final class Delegate: NSObject, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        let contentView = cell?.contentView
        let layer = contentView?.layer
        layer?.borderWidth = 5
    }

    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        let contentView = cell?.contentView
        let layer = contentView?.layer
        layer?.borderWidth = 0
        print(cell?.tag)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        CGSize(width: 50, height: 50)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        0
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
}

final class Listener {
    let closure: () -> ()

    init(closure: @escaping () -> ()) {
        self.closure = closure
    }

    @objc func action(_ target: UIButton) {
        closure()
    }
}

let frame = CGRect(x: 100, y: 60, width: 400, height: 600)
let layout = UICollectionViewFlowLayout()
let cv = UICollectionView(frame: frame, collectionViewLayout: layout)
let ds = DataSource()
let delegate = Delegate()
cv.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "cell")
cv.delegate = delegate
cv.dataSource = ds
cv.backgroundColor = .systemFill
cv.allowsMultipleSelection = true

let listener = Listener { cv.reloadData() }

let btn = UIButton(frame: CGRect(x: 200, y: 8, width: 200, height: 44))
btn.backgroundColor = .blue
btn.setTitle("Reload", for: .normal)
btn.addTarget(listener, action: #selector(Listener.action(_:)), for: .touchUpInside)

rootView.addSubview(btn)
rootView.addSubview(cv)

print(cv.allowsSelection)
print(cv.allowsMultipleSelection)

PlaygroundPage.current.liveView = rootView
